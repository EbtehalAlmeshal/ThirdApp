//
//  RecordSoundsViweController.swift
//  Pitch Perfect App.
//
//  Created by ابتهال عبدالعزيز on 04/02/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import UIKit
import AVFoundation

class RecordSoundsViweController: UIViewController , AVAudioRecorderDelegate {

    var audioRecorder: AVAudioRecorder!
  
  
 
    @IBOutlet weak var TabRecordLabel: UILabel!
    @IBOutlet weak var RecordButtom: UIButton!
    @IBOutlet weak var StopRecordingButtom: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        StopRecordingButtom.isEnabled = false
    }
    func configureUI(isRecording: Bool) {
        TabRecordLabel.text = isRecording ? "Recording in progress" : "Tap to record"
        StopRecordingButtom.isEnabled = isRecording
        RecordButtom.isEnabled = !isRecording
    }
 
    @IBAction func recordaudio(_ sender: UIButton) {
        print("recording")
        configureUI(isRecording: true)
     
    
        let dirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask, true)[0] as String
        let recordingName = "recordedVoice.wav"
        let pathArray = [dirPath, recordingName]
        let filePath = URL(string: pathArray.joined(separator: "/"))
        
        let session = AVAudioSession.sharedInstance()
              try! session.setCategory(.playAndRecord, mode: .default, options: .defaultToSpeaker)
        
        try! audioRecorder = AVAudioRecorder(url: filePath!, settings: [:])
        audioRecorder.delegate = self
        audioRecorder.isMeteringEnabled = true
        audioRecorder.prepareToRecord()
        audioRecorder.record()
        
    }
  
    
    @IBAction func StopRecording(_ sender: Any) {
     configureUI(isRecording: false)
        audioRecorder.stop()
        let audioSession = AVAudioSession.sharedInstance()
        try!audioSession.setActive(false)
    }
 
    
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if flag {
        performSegue(withIdentifier: "StopRecording", sender: audioRecorder.url)
        } else {
            print(" recording was not successful")
        }
 
}
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "StopRecording"{
           let playSoundsVS = segue.destination as! PlaySoundsViewController
            let recordedAudioURL = sender as!URL
            playSoundsVS.recordedAudioURL = recordedAudioURL
            
        }
    }

    
}
